package com.example.appprueba;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


public class Mediciondiaria extends AppCompatActivity {

    //declaro variables
    private Spinner spSpinner;
    String[] comunas = new String[]{"Puente Alto", "Macul", "San Miguel", "Lampa", "La Florida"};
    private EditText edid,edhora, edTemp, edhum;
    private ListView lista;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mediciondiaria);
        //lista
       CargarListaFirestore();


        db = FirebaseFirestore.getInstance();

        edid =findViewById(R.id.edid);
        edhora =findViewById(R.id.edhora);
        edTemp = findViewById(R.id.edTemp);
        edhum =findViewById(R.id.edhum);
        spSpinner =findViewById(R.id.spSpinner);
        lista =findViewById(R.id.lstLista);

        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, comunas);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSpinner.setAdapter(spinnerAdapter);

    }


    //envio de datos

    public void enviarDatosFirestore(View view) {

        String id = edid.getText().toString();
        String hora = edhora.getText().toString();
        String temperatura = edTemp.getText().toString();
        String humedad = edhum.getText().toString();
        String comuna = spSpinner.getSelectedItem().toString();

        //mapa de datos

      Map<String,Object> diario =new HashMap<>();
      diario.put("id",id);
      diario.put("hora",hora);
      diario.put("temperatura",temperatura);
      diario.put("humedad",humedad);
      diario.put("comuna",comuna);

        db.collection("diario")
                .document(id)
                .set(diario)
                .addOnSuccessListener(aVoid -> {

                    Toast.makeText(Mediciondiaria.this, "Datos enviados de forma correcta", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {

                    Toast.makeText(Mediciondiaria.this, "Errom de envio", Toast.LENGTH_SHORT).show();

                });
    }

    public void CargarLista(View view){
        CargarListaFirestore();
    }

    public void CargarListaFirestore(){

        FirebaseFirestore db =FirebaseFirestore.getInstance();

        db.collection("diario")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()){

                            List<String> listaMediciones = new ArrayList<>();

                            for (QueryDocumentSnapshot document:task.getResult()){
                            String linea ="||" + document.getString("id") + "||"
                                    + document.getString("hora") + "||"
                                    +document.getString("temperatura") + "||"+
                                    document.getString("humedad") + "||"+
                                    document.getString("comuna");
                                listaMediciones.add(linea);
                            }
                            ArrayAdapter<String> adaptador = new ArrayAdapter<>(
                               Mediciondiaria.this,
                                    android.R.layout.simple_list_item_1,
                                    listaMediciones
                            );
                            lista.setAdapter(adaptador);
                        }else {
                            Log.e("TAG","Error al descargar datos",task.getException());
                        }
                    }
                });




    }



}